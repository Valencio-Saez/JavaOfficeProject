/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdatehello_react_typescript"]("app",{

/***/ "./src/index.tsx":
/*!***********************!*\
  !*** ./src/index.tsx ***!
  \***********************/
/***/ (() => {

eval("throw new Error(\"Module parse failed: Unexpected token (42:0)\\nFile was processed with these loaders:\\n * ./node_modules/ts-loader/index.js\\nYou may need an additional loader to handle the result of these loaders.\\n| (0, client_1.createRoot)(document.getElementById('root'))\\n|     .render((0, jsx_runtime_1.jsx)(React.StrictMode, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.BrowserRouter, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: \\\"/\\\", element: (0, jsx_runtime_1.jsx)(Home_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: \\\"/admin\\\", element: (0, jsx_runtime_1.jsx)(ProtectedRoute_1.default, { allowedRole: \\\"admin\\\", children: (0, jsx_runtime_1.jsx)(AdminDashboard_1.default, {}) }) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: \\\"/login\\\", element: (0, jsx_runtime_1.jsx)(Login_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: \\\"/register\\\", element: (0, jsx_runtime_1.jsx)(Register_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: \\\"/edit-event/:eventId\\\", element: (0, jsx_runtime_1.jsx)(AdminEditEvent_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: \\\"/event/:eventId/attendees\\\", element: (0, jsx_runtime_1.jsx)(AdminViewAttendees_1.default, {}) })] }) }), React.StrictMode >\\n> );\\n| \");\n\n//# sourceURL=webpack://hello-react-typescript/./src/index.tsx?");

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("4625282384fc1c4c93f0")
/******/ })();
/******/ 
/******/ }
);